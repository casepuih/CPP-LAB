// pair.cpp file

#include "pair.h"


template <typename F, typename S> Pair<F,S>::Pair(F fst, S snd) : fst_{fst}, snd_{snd} {}

template <typename F, typename S> F Pair<F,S>::fst() const { return fst_; }
template <typename F, typename S> S Pair<F,S>::snd() const { return snd_; }


template <typename F, typename S> std::ostream& operator<<(std::ostream& out, const Pair<F,S>& rp) {
    out << "(" << rp.fst_ << "," << rp.snd_ << ")";
    return out;
  }