// stack_vec_impl.h.cpp file

#include "stack.h"
#include "stack_vec_impl.h"



template <typename T> StackVectorBasedImpl<T>::StackVectorBasedImpl() : data_{} {} ; 


template <typename T> T StackVectorBasedImpl<T>::pop() { 
	T last = data_.back(); 
	data_.pop_back(); 
	return last; 
}
	
	
template <typename T> void StackVectorBasedImpl<T>::push(T e) { 
	data_.emplace_back(e); 
}
	
template <typename T> bool StackVectorBasedImpl<T>::isEmpty() const { 
	return data_.empty(); 
}

template <typename T> int StackVectorBasedImpl<T>::size() const { 
	return static_cast<int>(data_.size()); 
}

template <typename T> T StackVectorBasedImpl<T>::peek() const { 
	return data_.back(); 
}


template <typename T>StackVectorBasedImpl<T>::~StackVectorBasedImpl() {}