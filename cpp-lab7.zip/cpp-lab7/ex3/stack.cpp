// stack.cpp file

#include "stack.h"


template <typename T> T Stack<T>::pop() = 0;
template <typename T> void Stack<T>::push(T e) = 0;
template <typename T>  bool Stack<T>::isEmpty() const = 0;
template <typename T> int Stack<T>::size() const = 0;
template <typename T> T Stack<T>::peek() const = 0;
template <typename T> Stack<T>::~Stack(){};
