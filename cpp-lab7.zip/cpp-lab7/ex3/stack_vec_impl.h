// stack_vec_impl.h file 

#include <ostream>
#include <iostream>
#include <string>
#include <vector>

template <typename T>class StackVectorBasedImpl : public Stack<T>
{
public:
  StackVectorBasedImpl() ;
  T pop() ;
  void push(T e) ;
  bool isEmpty() const ;
  int size() const ;
  T peek() const ;
  virtual ~StackVectorBasedImpl();

private:
  std::vector<T> data_;
};

