// pair.h file 

#include <ostream>
#include <iostream>
#include <string>

template <typename F, typename S>class Pair;

template <typename F, typename S>std::ostream& operator<<(std::ostream&, const Pair<F,S>&);

template <typename F, typename S >class Pair
{
public:
  Pair(F fst, S snd) ;
  F fst() const ;
  S snd() const ;

private:
  F fst_;
  S snd_;
};

