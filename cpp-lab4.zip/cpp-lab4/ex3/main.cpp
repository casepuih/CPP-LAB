#include <iostream>
#include <cmath>

using std::cout;
using std::endl;
using std::cin;
using std::ostream;
using std::istream;

class Vector2D
{
public:
  Vector2D(double x = 0, double y = 0) : x_{x}, y_{y} {}
  Vector2D(const Vector2D &other) : x_{other.x_}, y_{other.y_} {}
  ~Vector2D() { cout << "destructor of " << *this << endl; }

  Vector2D& operator=(const Vector2D &other) {
    if (&other != this) {
      this->x_ = other.x_;
      this->y_ = other.y_;
    }
    return *this;
  }

  Vector2D& operator+=(double scalar_value ){

	  this->x_ = x_ + scalar_value ;
	  this->y_ = y_ + scalar_value ;
	  return *this;
  }
  Vector2D& operator-(){ // unary minus: v = [1,2] => -v = [-1,-2]

	  this->x_ = - x_ ;
	  this->y_ = - y_  ;
	  return *this;
  }

  Vector2D& operator*=(double scalar_value) {

	  this->x_ = x_ * scalar_value ;
	  this->y_ = y_ * scalar_value ;
	  return *this;

  }

  Vector2D& operator-=(double scalar_value){

	  this->x_ = x_ - scalar_value ;
	  this->y_ = y_ - scalar_value ;
	  return *this;

  }
  Vector2D& operator+=(const Vector2D &v1){

	  this->x_ = x_ + v1.x_ ;
	  this->y_ = y_ + v1.y_ ;
	  return *this;

  }

  Vector2D& operator-=(const Vector2D &v1){

	  this->x_ = x_ - v1.x_ ;
	  this->y_ = y_ - v1.y_ ;
	  return *this;
  }

  double length() const { return sqrt(x_ * x_ + y_ * y_); }

private:
  double x_;
  double y_;

  friend Vector2D operator+(const Vector2D&, const Vector2D&);
  friend ostream& operator<<(ostream&, const Vector2D&);
  friend istream& operator>>(istream&, Vector2D&);

  friend Vector2D operator-(const Vector2D&, const Vector2D&);
  friend double operator*(const Vector2D&, const Vector2D&); // dot product
  friend Vector2D operator*(const Vector2D&, double); // 2d_vector * scalar_value
  friend Vector2D operator*(double, const Vector2D&); // scalar_value * 2d_vector

};

ostream &operator<<(ostream &os, const Vector2D &v)
{
  os << "[" << v.x_ << ", " << v.y_ << "]";
  return os;
}

istream& operator>>(istream& is, Vector2D& v)
{
  cout << "x = ";
  is >> v.x_;

  cout << "y = ";
  is >> v.y_;

  return is;
}

Vector2D operator+(const Vector2D &v1, const Vector2D &v2) {
  return Vector2D {v1.x_ + v2.x_, v1.y_ + v2.y_};
}


Vector2D operator-(const Vector2D &v1, const Vector2D &v2){

	return Vector2D {v1.x_ - v2.x_, v1.y_ - v2.y_};
}

double operator*(const Vector2D &v1, const Vector2D &v2) {

	return ((v1.x_ * v2.x_ )+ (v1.y_ * v2.y_));
}
Vector2D operator*(const Vector2D &v1, double scalar_value ){ // 2d_vector * scalar_value

	return Vector2D {v1.x_ * scalar_value, v1.y_ * scalar_value};
}
Vector2D operator*(double scalar_value, const Vector2D &v1){ // scalar_value * 2d_vector

	return Vector2D {scalar_value*v1.x_ , scalar_value*v1.y_ };
}

void demo(){

  Vector2D v1{1,2};
  Vector2D *pV = new Vector2D (3,4);
  cout << "v1 = " << v1 << ", *pV = " << (*pV) << endl;
  cout << "|*pV| = " << pV->length() << endl; // pV->length() = (*pV).length()

  cout << "About to execute Vector2D v3{v1 + *pV}..." << endl;
  Vector2D v3{v1 + *pV}; // v1 + *pV = operator+(v1, *pV)
  cout << "v3 = " << v3 << ", |v3| = " << v3.length() << endl;

  cout << "About to execute Vector2D v4 = v1 + *pV + v3;..." << endl;
  Vector2D v4 = v1 + v3 + *pV;
  cout << "v4 = " << v4 << endl;

  Vector2D v5;
  cout << "Specify v5 components:" << endl;
  cin >> v5;
  cout << "v5 = " << v5 << endl;
  delete pV;
}


void demo1() {


  Vector2D v2{2,3};
  Vector2D v3{3,1};

  cout << "v2 = " << v2 << endl;
  cout << "v3 = " << v3 << endl;
  cout << "v2 + v3 = " << v2 + v3 << endl;
  cout << "v2 - v3 = " << v2 - v3 << endl;
  cout << "v2 * v3 = " << v2 * v3 << endl;
  cout << "v2 * 6 = " << v2 * 6 << endl;
  cout << "6 * v2 = " << 6*v2 << endl;

}

void demo2(){

  Vector2D v2{2,3};
  Vector2D v3{3,1};
  cout << "v2 = " << v2 << endl;
  cout << "v3 = " << v3 << endl;
  v2 += v3 ; 
  cout << "v2 += v3 : " << v2 << endl;
  cout << "v2 = " << v2 << endl;
  v2 -= v3 ; 
  cout << "v2 -= v3 : " << v2 << endl;
  cout << "v2 = " << v2 << endl;
  v2 *= 3 ; 
  cout << "v2 *= 3 : " << v2 << endl;

}

void demo3(){

  Vector2D v2{2,3};
  cout << "v2 = " << v2 << endl;
  v2 += 6 ; 
  cout << "v2 += 6 : " << v2 << endl;
  cout << "v2 = " << v2 << endl;
  v2 -= 5 ; 
  cout << "v2 -= 5 : " << v2 << endl;
  cout << "v2 = " << v2 << endl;
  v2 = -v2 ; 
  cout << "v2 = -v2 : " << v2 << endl;


}


int main()
{
    //demo() ;
    //demo1(); 
    //demo2() ; 
    demo3() ;

  return 0;
}
