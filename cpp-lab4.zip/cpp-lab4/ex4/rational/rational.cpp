// rational.cpp file

#include <iostream>
#include "rational.h"

// construtors
Rational::Rational(){}

Rational::Rational(int numerator, int denominator){
  numer = numerator;
  denom = denominator ;
}

Rational::Rational(const Rational& copy){

  this->numer = copy.numer;
  this->denom = copy.denom ;
}

Rational& Rational::operator=(Rational const& other){

  if (&other != this) {
    this->numer = other.numer;
    this->denom = other.denom;
  }
  return *this;
}

// destructor
Rational::~Rational() {}


Rational& Rational::operator=(int i){
  numer = i ;
  denom = 1 ;
  return *this;
}

int Rational::numerator() const {
  return numer;
}
int Rational::denominator() const {
  return denom;
}

Rational Rational::normalize(Rational const& other) {

  Rational r(1,1) ;
  return r ;
}

Rational Rational::normalized(int numerator, int denominator){

   Rational r1(numerator, denominator) ;
   while (numerator !=denominator){
       if (numerator>denominator){
           numerator = numerator-denominator ;
       }else{
           denominator = denominator -numerator;
       }
   }
   r1.gcdND = numerator ;
   std::cout << "gcd =" << r1.gcdND << std::endl ;
   return r1 ;
}

Rational Rational::operator+(Rational const& other) const{

  int numerNew = (numer*other.denom)+ (denom*other.numer) ;
  int denomNew = denom*other.denom ;
  Rational result(numerNew, denomNew) ;
  return result;

}
Rational Rational::operator-(Rational const& other) const {

  int numerNew = (numer*other.denom)-(denom*other.numer) ;
  int denomNew = denom*other.denom ;
  Rational result(numerNew, denomNew) ;
  return result;

}
Rational Rational::operator*(Rational const& other) const{

  return Rational(this->numer*other.numer, this->denom*other.denom) ;
}
Rational Rational::operator/(Rational const& other) const{

  return Rational(this->numer*other.denom, this->denom*other.numer);

}

Rational Rational::operator+() const{

  return Rational(this->numer*this->denom*2, this->denom*2);
}
Rational Rational::operator-() const{

  return Rational(0,1);
}

bool Rational::operator==(Rational const& other) const{
  if ((this->numer == other.numer) && (this->denom == other.denom)){
    return true ;
  }else{
   return false ;
  }
}
bool Rational::operator>=(Rational const& other) const{

  if ((this->numer>= other.numer) && (this->denom <= other.denom)) {
     return true;
  }else{
     return false ;
  }
}
bool Rational::operator<=(Rational const& other) const{

  if ((this->numer<= other.numer) && (this->denom >= other.denom)) {
     return true;
  }else{
     return false ;
  }
}

bool Rational::operator>(Rational const& other) const{

  if ((this->numer>= other.numer) && (this->denom <= other.denom)) {

     if ((this->numer == other.numer) && (this->denom == other.denom)) {
        return false ;
     }else{
         return true;
     }
  }else{
     return false ;
  }
}

bool Rational::operator<(Rational const& other) const {

  if ((this->numer<= other.numer) && (this->denom >= other.denom)) {

    if ((this->numer == other.numer) && (this->denom == other.denom)) {
        return false ;
     }else{
       return true;
     }
  }else{
     return false ;
  }
}

void Rational::initialize(int numerator, int denominator){

  this->numer = numerator ;
  this->denom = denominator ;
}

std::ostream& operator<<(std::ostream & out, const Rational &r){


    if ((r.denominator() > 0) && (r.numerator() > 0)){
          out << r.numer << "/" << r.denom << " " ;
    }else {
        if (r.denominator()<0 && r.numerator() <0 ){
              out <<"" << -r.numer << "/" << -r.denom << "" ;
        }else if (r.numerator()<0){
            out <<" (-" << -r.numer << "/" << r.denom << ")" ;
        }else{
            out <<"(-" << r.numer << "/" << -r.denom << ")" ;
        }
    }

  return out ;
}

std::istream& operator>>(std::istream & in, Rational &r){

  std::cout << "numer = ";
  in >> r.numer;
  std::cout << "denom = ";
  in >> r.denom;
  return in ;
}

Rational operator+(Rational const& r, int i) {

  return Rational(r.numerator()+(r.denominator()*i),r.denominator()) ;

}
Rational operator+(int i, Rational const& r)
{
  return Rational((r.denominator()*i)+r.numerator(),r.denominator()) ;
}

Rational operator-(Rational const& r, int i){

  return Rational(r.numerator()-(r.denominator()*i),r.denominator()) ;
}
Rational operator-(int i, Rational const& r){

  return Rational((r.denominator()*i)-r.numerator(),r.denominator()) ;
}

Rational operator*(Rational const& r, int i){

  return Rational((r.numerator()*i), r.denominator()) ;
}
Rational operator*(int i, Rational const& r){

  return Rational((i*r.numerator()), r.denominator()) ;
}

Rational operator/(Rational const& r, int i){

  return Rational(r.numerator(), (r.denominator()*i)) ;

}
Rational operator/(int i, Rational const& r){

  return Rational((i*r.denominator()), r.numerator()) ;
}

