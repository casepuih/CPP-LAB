// vec2d.cpp file
#include <iostream>
#include <fstream>
#include <vector>
#include "vec2d.h"


Vec2D::Vec2D(){} ; 

Vec2D::Vec2D(double x, double y) {
 x_ = x ; 
 y_ = y ;
}

std::ostream& operator<<(std::ostream& out, const Vec2D& v)
{
  out << "[" << v.x_ << "," << v.y_ << "]";
  return out;
}

double Vec2D::getX(){
   return x_ ; 
}

double Vec2D::getY(){
   return y_ ; 
} 

void Vec2D:: binSerialiseTo(const char* fileName){

  std::ofstream out(fileName, std::ios_base::binary);
  if (!out) {
   	 std::cout << "Cannot open file " << fileName << std::endl;
    //	return;
  }
  out.write(reinterpret_cast<char*>(this), sizeof(this));
  out.close();
}


Vec2D Vec2D::binDeserialiseFrom(const char* fileName){
  std::ifstream in(fileName, std::ios_base::binary);
  if (!in) {
   	 std::cout << "Cannot open file " << fileName << std::endl;
    	//return;
  }
  Vec2D v;
  in.read(reinterpret_cast<char*>(&v), sizeof(v)); 
  in.close();
  return v ; 
}
