// main.cpp file
#include <iostream>
#include <fstream>
#include <vector>
#include "vec2d.h"

using namespace std;

void writeIntoBinFileDemo(const char* fileName, const vector<Vec2D>& vecOfV2D)
{
  ofstream out(fileName, ios_base::binary);
  if (!out) {
    cout << "Cannot open file " << fileName << endl;
    return;
  }
  for (auto v : vecOfV2D) {
    out.write(reinterpret_cast<char*>(&v), sizeof(v));
  }
  out.close();
}

void readFromBinFileDemo(const char* fileName, vector<Vec2D>& vecOfV2D)
{
  std::ifstream in(fileName, ios_base::binary);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return;
  }

  Vec2D v;
  while (in.read(reinterpret_cast<char*>(&v), sizeof(v))) {
    vecOfV2D.emplace_back(v);
    cout << v << endl; 
  }
  in.close();
}

void writeIntoBinFileAppend(const char* fileName, const vector<Vec2D>& vecOfV2D)
{
  ofstream out(fileName, ios::out | ios::binary | ios::in | ios_base::app);
  if (!out) {
    cout << "Cannot open file " << fileName << endl;
    return;
  }

  for (auto v : vecOfV2D) {
    out.write(reinterpret_cast<char*>(&v), sizeof(v));
  }
  out.close();
}

double fRand(double fMin, double fMax)
{
    double f = (double)rand() / RAND_MAX;
    return fMin + f * (fMax - fMin);
}

void appendBinVec2D(const char* fName, int nbInstance, double min, double max){

  vector<Vec2D> vecOfV2D{} ; 
  double x, y ; 
  for (int i = 0 ; i < nbInstance ; i++){ 
     x = fRand(min, max) ; 
     y = fRand(min, max) ; 
     vecOfV2D.push_back(Vec2D{x, y}) ; 
  }	
  writeIntoBinFileAppend(fName, vecOfV2D);
}


void writePositiveComponents(const char* fNameR, const char* fNameW ){

  ifstream inR(fNameR, ios_base::binary);
  ofstream outW(fNameW, ios::out | ios::binary | ios::in | ios_base::app);

  if (!inR) {
    cout << "Cannot open file " << fNameR << endl;
    return;
  }

  if (!outW) {
    cout << "Cannot open file " << fNameW << endl;
    return;
  }

  Vec2D v;
  while (inR.read(reinterpret_cast<char*>(&v), sizeof(v))) {
    if ((v.getX()>0) && (v.getY()>0)){
       outW.write(reinterpret_cast<char*>(&v), sizeof(v));
    }
  }
  inR.close() ; 
  outW.close() ; 
}


int main()
{
  vector<Vec2D> vecOfV2D1 {
    Vec2D{1.2, 2.3},
    Vec2D{1.23, 4.56},
    Vec2D{12.345, 67.890}
  };

  const char* fName = "vec2D.dat";
  const char* fNameOther = "vec2DOther.dat";
  //writeIntoBinFileDemo(fName, vecOfV2D1);

  //vector<Vec2D> vecOfV2D2;
  //readFromBinFileDemo(fName, vecOfV2D2);

  //for (auto v : vecOfV2D2) {
    //cout << v << endl;
  //}
 // Vec2D v1{12.34, 567.89};
 // v1.binSerialiseTo("v1.dat");#include "vec2d.h"
 // Vec2D v2 = Vec2D::binDeserialiseFrom("v1.dat");
 // cout << v2 << endl;
 
  //appendBinVec2D(fName, 10 , -10.0, 10.0) ;
  vector<Vec2D> vecOfV2D3;
  cout << "read in : " <<  fName << endl ; 
  readFromBinFileDemo(fName, vecOfV2D3);
  writePositiveComponents(fName,fNameOther) ; 

  vector<Vec2D> vecOfV2D4;
  cout << "read (only positive compo): " << fNameOther << endl ; 
  readFromBinFileDemo(fNameOther, vecOfV2D4);

  return 0;
}
	
