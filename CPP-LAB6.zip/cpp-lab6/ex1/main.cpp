#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cstdio>

using namespace std;

void write2TxtFileDemo1(const char* fileName, const string &text)
{
  ofstream out;
  out.open(fileName); //=open(fileName,ios_base::trunc) - truncate the file if it exists

  if (!out) {
    cout << "Cannot open file " << fileName << endl;
    //return;
  }

  out << text;
  out.close();
}

void write2TxtFileDemo2(const char* fileName, const string &text)
{
  ofstream out(fileName, ios::app); //ios::app - append to end-of-file.
  if (!out) {
    cout << "Cannot open file " << fileName << endl;
   //return;
  }

  out << text;
  out.close();
}

string fileToString(const char* fileName)
{
  std::ifstream in(fileName);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return 0;
  }

  std::stringstream buffer;
  buffer << in.rdbuf();
  in.close();

  return buffer.str();
}

void writeToFilesDemo(const char* fName)
{
  cout << "writeToFilesDemo..." << endl;
  write2TxtFileDemo1(fName, string("aaa\nbbb"));
  cout << "(1): " << fName << " now contains: " << endl << fileToString(fName) << endl;
  write2TxtFileDemo1(fName, string("\nccc\nddd"));
  cout << "(2): " << fName << " now contains: " << endl << fileToString(fName) << endl;

  write2TxtFileDemo1(fName, string("aaa\nbbb"));
  cout << "(3): " << fName << " now contains: " << endl << fileToString(fName) << endl;
  write2TxtFileDemo2(fName, string("\nccc\nddd"));
  cout << "(4): " << fName << " now contains: " << endl << fileToString(fName) << endl;
  write2TxtFileDemo2(fName, string("\neee\nfff"));
  cout << "(5): " << fName << " now contains: " << endl << fileToString(fName) << endl;
}

void getCharAndGetLineDemo(const char* fName)
{
  cout << "getCharAndGetLineDemo..." << endl;
  std::ifstream in(fName);
  if (!in) {
    cout << "Cannot open file " << fName << endl;
    //return;
  }

  char ch;
  cout << "Reading character by character..." << endl;
  while (in.get(ch)) {
    cout << ch;
  }

  // reset "file pointer" to the beginning of the file
  in.clear();
  in.seekg (0, in.beg);
  // start reading again, but this time line by line

  cout << endl << "Now reading line by line..." << endl;
  for (string line; getline(in,line); ) {
    cout << line << endl;
  }

  // the same as above, but using 'while' loop
  string line;
  while (getline(in, line)) {
    cout << line << endl;
  }

  in.close();
}

int countCharacters(const char* fileName)
{
  std::ifstream in(fileName);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return 0;
  }

  char character; int count = 0;
  while (in >> character){
  	++count ; 
  }
  in.close();
  return count; 
}

int countLines(const char* fileName)
{
  std::ifstream in(fileName);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return 0;
  }

  string line; int count = 0;
  while(!in.eof()) {
	getline(in, line);
	count ++;	
  }
  in.close() ; 
  return count; 
}

void appendFiles(const char* fileName1, const char* fileName2)
{
  std::ifstream in(fileName2);
  if (!in) {
    cout << "Cannot open file " << fileName2 << endl;

  }

  std::ofstream out(fileName1, std::ios_base::app | std::ios_base::out);

  string line;
  while(!in.eof()) {
        out << "\n" ; 
	getline(in, line);
	out << line ; 	
  }
  out.close() ; 
  in.close() ; 
}

void readFile(const char* fileName1, const char* fileName2) {
  
  ifstream in(fileName1);
  ofstream newFile;
  newFile.open(fileName2); //=open(fileName,ios_base::trunc) - truncate the file if it exists

  if (!in) {
    cout << "Cannot open file " << fileName1 << endl;
  }
  
  string line;
  while(!in.eof()) {
        newFile << "\n" ; 
	getline(in, line);
	newFile << line ; 	
  }
  in.close() ;
  newFile.close();  
}



void concatToNewFile(const char* fileName1, const char* fileName2, const char* newName)
{
  appendFiles(newName, fileName1) ; 
  appendFiles(newName, fileName2) ; 
}

int countWords(const char* fileName)
{
  std::ifstream in(fileName);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return 0;
  }

  string word; 
  int count = 0;
  while (in >> word)
  {
    count++;
  }
  in.close() ; 
  return count; 
}

int countWhitespace(const char* fileName)
{
  std::ifstream in(fileName);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return 0;
  }

  int count = 0;
  while (!in.eof())
  {
    if (32 == in.get() ) {
          count++;
    }
  }
  in.close() ; 
  return count; 
}

string replaceLine(string line, string toReplace, string replace){

    int len, loop=0;
    string nword="", let;
    len=line.length();
    len--;
    while(loop<=len){
        let=line.substr(loop, 1);
        if(let==toReplace){
            nword=nword+replace;
        }else{
            nword=nword+let;
        }
        loop++;
    }
    return nword;

}


void changeTABtoSpace(const char* fileName)
{


  string newName = fileName ; 
  string oldName = newName + "~"; 
  const char* oldName1 = oldName.c_str() ; 
  std::rename(fileName, oldName1);

  std::ifstream old_file(oldName);
  std::ofstream new_file(newName);

  string toReplace = "\t" ; 
  string replace = " ";

  if (!old_file) {
    cout << "Cannot open file " << oldName << endl;
  }
  
  string line;
  while(!old_file.eof()) {
	getline(old_file, line);
        string newLine = replaceLine(line, toReplace, " ") ; 
        new_file << newLine << "\n" ;  
  }
  old_file.close() ; 
  new_file.close() ; 
}



int main()
{
  const char* fName = "textfile.txt";
  const char* fName1 = "txtToAppend.txt";
  //writeToFilesDemo(fName);
  //cout << endl;
  //getCharAndGetLineDemo(fName);
  //int num = countCharacters(fName) ; 
  //cout << " Nb characters : " << num << endl ; 
  //int numLines = countLines(fName) ; 
  //cout << " Nb lines : " << numLines << endl ; 
  
  //appendFiles(fName, fName1) ; 
  //concatToNewFile(fName, fName1, "newFile.txt") ; 

  //int words = countWords(fName1) ; 
  //cout << " Nb words : " << words << endl ;   

  //int whitespace = countWhitespace(fName1) ; 
  //cout << " Nb whitespace : " << whitespace << endl ; 
  
  changeTABtoSpace(fName1) ;



 

  return 0;




}
