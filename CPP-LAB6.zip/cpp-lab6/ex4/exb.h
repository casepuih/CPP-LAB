// exb.h file


#include <ostream>
#include <iostream>
#include <exception>
#include <sstream>
#include <string>

//#include "exa.h"

class ExB : public ExA
{
public:
  ExB(const char* msg) ;
  ExB(const ExB& other) ;
  std::string description() const noexcept override;
  virtual ~ExB() override ;
} ; 
