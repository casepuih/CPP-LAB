// myexception.h file

#include <ostream>
#include <iostream>
#include <exception>
#include <sstream>
#include <string>

// Error handling demo 3.2 (using exceptions, only in C++)
class MyException : public std::exception {
public:
  const char* what() const noexcept ; 
};


