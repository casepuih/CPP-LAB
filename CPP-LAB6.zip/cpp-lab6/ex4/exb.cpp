// exb.cpp file
#include <ostream>
#include <iostream>
#include <exception>
#include <sstream>

#include "exa.h"
#include "exb.h"




ExB::ExB(const char* msg) { 
   ExA{msg} ; 
   std::cout << "ExB constructor..." << std::endl; 
}

ExB::ExB(const ExB& other) { 
  ExA{other} ; 
  std::cout << "ExB copy constructor..." << std::endl; 
}

std::string ExB::description() const noexcept 
{
  return ("ExB: " + msg_);
}

ExB::~ExB() { 
  std::cout << "ExB destructor..." << std::endl; 
}

