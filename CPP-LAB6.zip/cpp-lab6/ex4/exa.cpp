// exa.cpp file

#include "exa.h"


ExA::ExA()  { 
   std::cout << "ExA default constructor..." << std::endl; 
} 


ExA::ExA(const char* msg) : msg_{msg} { 
   std::cout << "ExA constructor..." << std::endl; 
}

ExA::ExA(const ExA &other):msg_{other.msg_}  { 
  std::cout << "ExA copy constructor..." << std::endl; 
}

std::string ExA::description() const noexcept
{
  return ("ExA: " + msg_);
}

ExA::~ExA() { 
  std::cout << "ExA destructor..." << std::endl;
}





