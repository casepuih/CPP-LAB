
// exa.h file

#include <iostream>
#include <exception>
#include <sstream>
#include <string>


class ExA
{
public:
  ExA() ; 
  ExA(const char* msg) ;
  ExA(const ExA& other) ;
  virtual std::string description()  const noexcept;
  virtual ~ExA() ;

protected:
  const std::string msg_;
};

class ExB ; 
