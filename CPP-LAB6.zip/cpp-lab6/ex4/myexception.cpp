// myexception.cpp file


#include "myexception.h"

const char* MyException::what() const noexcept { return "MyException"; }



