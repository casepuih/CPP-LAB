
//main.cpp 
#include "exa.h"
#include "exb.h"
#include "myexception.h"

using namespace std;

//Error handling demo 1
double f1(int x)
{
  if (x == 1) {
    abort();
  } else {
    return (1 + x) / (1 - x);
  }
}

//Error handling demo 2 ('C' style)
enum class OpStatus {OK, ERROR};

OpStatus f2(int x, double &opResult)
{
  if (x == 1) {
    return OpStatus::ERROR;
  } else {
    opResult = (1 + x) / (1 - x);
    return OpStatus::OK;
  }
}

double f3(int x) noexcept(false)
{
  if (x == 1) {
    throw "Error: x cannot be 1";
  } else {
    return (1 + x) / (1 - x);
  }
}

double f4(int x) noexcept(false)
{
  if (x == 1) {
    throw MyException{};
  } else {
    return (1 + x) / (1 - x);
  }
}

void errorHandlingDemo1()
{
  cout << "errorHandlingDemo1()..." << endl;
  cout << "f1(0) = " << f1(0) << endl;
  cout << "f1(1) = " << f1(1) << endl;
}

void errorHandlingDemo2()
{
  cout << "errorHandlingDemo2()..." << endl;
  double opRes;
  OpStatus opStat = f2(0, opRes);
  if (opStat == OpStatus::OK) {
    cout << "f2(0,opRes) = " << opRes << endl;
  } else {
    cout << "Error occurred while calling f2(0,opRes)..." << endl;
  }

  opStat = f2(1, opRes);
  if (opStat == OpStatus::OK) {
    cout << "f2(1,opRes) = " << opRes << endl;
  } else {
    cout << "Error occurred while calling f2(1,opRes)..." << endl;
  }
}

void errorHandlingDemo3()
{
  cout << "errorHandlingDemo3()..." << endl;
  try {
    cout << "f3(0) = " << f3(0) << endl;
    cout << "f3(1) = " << f3(1) << endl;
  }
  catch (const char *s)
  {
    cout << "An exception (" << s << ") was thrown, but was caught here" << endl;
  }
  catch (...) // default exception handler; it catches all exceptions
  {
    cout << "Default exception handler caught an exception" << endl;
  }
}
void errorHandlingDemo4()
{
  cout << "errorHandlingDemo4()..." << endl;
  try {
    cout << "f4(0) = " << f4(0) << endl;
    cout << "f4(1) = " << f4(1) << endl;
  }
  catch (const MyException &e)
  {
    cout << "An exception (" << e.what() << ") was thrown, but was caught here" << endl;
  }
  catch (...) // default exception handler, it catches all exceptions
  {
    cout << "Default exception handler caught an exception" << endl;
  }
}


double f5(int x) noexcept(false)
{
  if (x == 1) {
    throw ExA{"x == 1"};
  } else if (x == 2) {
    throw ExB{"x == 2"};
  } else {
    return (1 + x) / ((1 - x) * (2 - x));
  }
}

void errorHandlingDemo5()
{
  cout << "errorHandlingDemo5()..." << endl;
  try {
    cout << "f5(0) = " << f5(0) << endl;
    //cout << "f5(1) = " << f5(1) << endl;
    cout << "f5(2) = " << f5(2) << endl;
  }
    catch (const ExA &ea)
  {
    cout << "ExA handler..." << endl;
    cout << "An exception (" << ea.description() << ") was thrown, but was caught here" << endl;
  }
  
    catch (const ExB &eb)
  {
    cout << "ExB handler..." << endl;
    cout << "An exception (" << eb.description() << ") was thrown, but was caught here" << endl;
  }

  catch (...) // default exception handler, it catches all exceptions
  {
    cout << "Default exception handler caught an exception" << endl;
  }
  
  
  
 // catch (const ExB &eb)
 // {
 //   cout << "ExB handler..." << endl;
 //   cout << "An exception (" << eb.description() << ") was thrown, but was caught here" << endl;
 // }
 // catch (const ExA &ea)
 // {
 //   cout << "ExA handler..." << endl;
 //   cout << "An exception (" << ea.description() << ") was thrown, but was caught here" << endl;
 // }
 // catch (...) // default exception handler, it catches all exceptions
 // {
 //   cout << "Default exception handler caught an exception" << endl;
 // }
}

int main()
{
  //errorHandlingDemo1();
  //cout << endl;
  errorHandlingDemo2();
  cout << endl;
  errorHandlingDemo3();
  cout << endl;
  errorHandlingDemo4();

  return 0;
}
