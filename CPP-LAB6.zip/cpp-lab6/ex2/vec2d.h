// vec2d.h file

#include <iostream>
#include <fstream>

class Vec2D
{
public:
  Vec2D(); 
  Vec2D(double, double) ; 
  void serialiseTo(const char* fileName); 
  static Vec2D deserialiseFrom(const char* fileName);

private:
  double x_;
  double y_;
  friend std::ostream& operator<<(std::ostream&, const Vec2D&);
  friend std::istream& operator>>(std::istream&, Vec2D&);
};
