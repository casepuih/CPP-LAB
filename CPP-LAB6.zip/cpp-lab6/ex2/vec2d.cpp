// vec2d.cpp file
#include <iostream>
#include <fstream>
#include <vector>
#include "vec2d.h"

Vec2D::Vec2D(){} ; 

Vec2D::Vec2D(double x, double y) {
 x_ = x ; 
 y_ = y ;

} 

std::ostream& operator<<(std::ostream& out, const Vec2D& v)
{
  out << "[" << v.x_ << "," << v.y_ << "]";
  return out;
}

std::istream& operator>>(std::istream& in, Vec2D& v)
{
  char c;
  double x, y;

  //    [  1.2    , 12.3    ]
  //    c    x    c    y    c
  in >> c >> x >> c >> y >> c;

  // no error, so we create class different file c++ friend functioncan set the object data (i.e. x_ and y_)
  v.x_ = x;
  v.y_ = y;

  return in;
}
void Vec2D::serialiseTo(const char* fileName) {

    std::ofstream out(fileName);
    if (!out) {
      std::cout << "Cannot open file " << fileName << std::endl;
      return;
    }

    out << *this << std::endl;
    out.close();
  }

Vec2D Vec2D::deserialiseFrom(const char* fileName){

    std::ifstream in(fileName);
    if (!in) {
      std::cout << "Cannot open file " << fileName << std::endl;
     // return;
    }
    Vec2D v ; 
    in >> v; 
    in.close();
    return v; 
  }


