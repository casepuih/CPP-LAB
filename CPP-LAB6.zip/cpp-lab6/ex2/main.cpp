// main.cpp file
#include <iostream>
#include <fstream>
#include <vector>
#include "vec2d.h"

using namespace std;

void serialiseIntoTxtFileDemo(const char* fileName, const vector<Vec2D>& vecOfV2D)
{
  ofstream out(fileName) ; 
  if (!out) {
    cout << "Cannot open file " << fileName << endl;
    return;
  }
  for (auto v : vecOfV2D) {
    out << v << endl;
  }

  out.close();
}

void serialiseIntoTxtFileAppend(const char* fileName, const vector<Vec2D>& vecOfV2D)
{
  ofstream out(fileName,  ios::app) ; 
  if (!out) {
    cout << "Cannot open file " << fileName << endl;
    return;
  }
  for (auto v : vecOfV2D) {
    out << v << endl;
  }
  out.close();
}

void deserialiseFromTxtFileDemo(const char* fileName, vector<Vec2D>& vecOfV2D)
{
  ifstream in(fileName);
  if (!in) {
    cout << "Cannot open file " << fileName << endl;
    return;
  }
  Vec2D v;
  while (in >> v) {
    vecOfV2D.emplace_back(v);
  }
  in.close();
}


double fRand(double fMin, double fMax)
{
    double f = (double)rand() / RAND_MAX;
    return fMin + f * (fMax - fMin);
}


void generateVec2D(const char* fName, int nbInstance, double min, double max){

  vector<Vec2D> vecOfV2D{} ; 
  double x, y ; 

  for (int i = 0 ; i < nbInstance ; i++){  void serialiseTo(const char* fileName);
     x = fRand(min, max) ; 
     y = fRand(min, max) ; 
     vecOfV2D.push_back(Vec2D{x, y}) ; 
  }	
  serialiseIntoTxtFileDemo(fName, vecOfV2D);
}


void appendVec2D(const char* fName, int nbInstance, double min, double max){

  vector<Vec2D> vecOfV2D{} ; 
  double x, y ; 
  for (int i = 0 ; i < nbInstance ; i++){ 
     x = fRand(min, max) ; 
     y = fRand(min, max) ; 
     vecOfV2D.push_back(Vec2D{x, y}) ; 
  }	
  serialiseIntoTxtFileAppend(fName, vecOfV2D);
}

int main()
{
  const char* fName = "vec2D.txt";
  vector<Vec2D> vecOfV2D1 {
    Vec2D{1.2, 2.3},
    Vec2D{1.23, 4.56},
    Vec2D{12.345, 67.890}
  };
  vector<Vec2D> vecOfV2D2;
  serialiseIntoTxtFileDemo(fName, vecOfV2D1);
  deserialiseFromTxtFileDemo(fName, vecOfV2D2);

  for (auto v : vecOfV2D2) {
    cout << v << endl;
  }
  generateVec2D("generateVec2D.txt", 5, 1.0, 10.0) ; 
  //Vec2D v1{12.34, 567.89};
  //v1.serialiseTo("v1.txt");
  //Vec2D v2 = Vec2D::deserialiseFrom("v1.txt");
  //cout << v2 << endl;
  //appendVec2D(fName, 4 , 1.0, 10.0) ;
  return 0;
}
