#include <iostream>
#include <vector>
#include <list>
#include <deque>
#include <set>
#include <algorithm>
#include <random>
#include <chrono>
#include <iterator>
#include <time.h>

using namespace std;


template <typename T> ostream& operator<<(ostream &out, const vector<T> &v)
{
  out << "[";
  const auto vs = v.size();
  if (vs > 0) {
    for (size_t i = 0; i < vs - 1; ++i) {
      out << v[i] << ",";
    }
    out << v.at(vs - 1); // out << v[vs - 1];
  }
  out << "]";

  return out;
}


template <typename IterT> inline bool isThisLastElem(IterT curElemIter, IterT endIter)
{
   return (++curElemIter == endIter);
}



template <typename IterT> void print_elems_from_to(IterT begin, IterT end)
{
   cout << "[";
   IterT it = begin;
   for (it = begin; it != end; ++it) {
      cout << (*it);
      if (!isThisLastElem(it, end)) {
         cout << ",";
      }
   }
   cout << "]";
}

inline bool isGreaterThan5(int i)
{
   return i > 5;
}


void stl_algorithmsDemo1()
{
   cout << "stl_algorithmsDemo1()..." << endl;

   vector<int> v1 = {7, 2, 5, 9, 4, 1, 6, 8, 3};
   vector<int>::const_iterator min_pos = min_element(v1.cbegin(), v1.cend());
   auto max_pos = max_element(v1.cbegin(), v1.cend());

   cout << "Finding min and max elem in v1 = {7, 2, 5, 9, 4, 1, 6, 8, 3}...";
   cout << "\n(minOfv1, maxOfv1) = (" << *min_pos << "," << *max_pos << ")";

   cout << "\nSorting v1 = {7, 2, 5, 9, 4, 1, 6, 8, 3}";
   sort(v1.begin(), v1.end());
   cout << "\nAfter calling sort(v1.begin(), v1.end()), v1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   cout << "\nReversing elements from 'the position of 5' to the last...";
   auto posOf5 = find(v1.begin(), v1.end(), 5);
   reverse(posOf5, v1.end());
   cout << "\nAfter calling reverse(posOf5, v1.end()), v1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   auto seed = chrono::system_clock::now().time_since_epoch().count();
   cout << "\nShuffling elements of v1...";
   shuffle(v1.begin(), v1.end(),
         default_random_engine(static_cast<unsigned>(seed)));
   cout << "\nv1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   auto posOfGreaterThan5 = find_if(v1.cbegin(), v1.cend(), isGreaterThan5);
   if (posOfGreaterThan5 == v1.end()) {
      cout << "\nNo elems in v1 which are greater than 5";
   } else {
      cout << "\nThe first elem greater than 5 in ";
      print_elems_from_to(v1.cbegin(), v1.cend());
      cout << " is " << *posOfGreaterThan5;
   }

   cout << "\nAnd the same with the use of lambda expression...";
   posOfGreaterThan5 = find_if(v1.cbegin(), v1.cend(), [](int i) { return i > 5; });
   cout << "\nThe first elem greater than 5 in ";
   print_elems_from_to(v1.cbegin(), v1.cend());
   cout << " is " << *posOfGreaterThan5;
}


void stl_algorithmsDemo2()
{
   cout << "stl_algorithmsDemo2()..." << endl;

   vector<int> v1 {1,2,3,4,5,6,7};
   vector<int> v2 {9,8,3,4,5,6,7,1,2,0};

   cout << "v1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());
   cout << "\nv2 = ";
   print_elems_from_to(v2.cbegin(), v2.cend());

   cout << "\nChecking whether v1[2:6] == v2[2:6], i.e whether ";
   print_elems_from_to(v1.cbegin()+2, v1.cend());
   cout << " == ";
   print_elems_from_to(v2.cbegin()+2, v2.cbegin() + static_cast<long>(v1.size()));
   if (equal(v1.begin()+2, v1.end(), v2.begin()+2)) {
      cout << "\nYes, v1[2:6] == v2[2:6]";
   } else {
      cout << "\nv1[2:6] != v2[2:6]";
   }
}

void stl_algorithmsDemo3()
{
   cout << "stl_algorithmsDemo3()..." << endl;

   list<int> lst1 {1,2,3,4,5,6,7,8,9};
   vector<int> v1(lst1.size());
   cout << "lst1 = ";
   print_elems_from_to(lst1.cbegin(), lst1.cend());
   cout << "\nv1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());
   cout << "\nv1.size() = " << v1.size()
        << ", v1.capacity = " << v1.capacity();

   cout << "\nCopying elems from lst1 to v1...";
   copy(lst1.cbegin(), lst1.cend(), v1.begin());
   cout << "\nv1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());
}


void stl_algorithmsDemo4()
{
   cout << "stl_algorithmsDemo4()..." << endl;

   list<int> lst1 {1,2,3,4,5,6,7,8,9};
   cout << "lst1 = ";
   print_elems_from_to(lst1.cbegin(), lst1.cend());

   vector<int> v1;
   cout << "\nCopying elements of lst1 into v1 by appending them...";
   copy (lst1.cbegin(), lst1.cend(), back_inserter(v1));
   cout << "\nv1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   deque<int> deq1;
   cout << "\nCopying elements of lst1 into deq1 by inserting them at the front...";
   copy(lst1.cbegin(), lst1.cend(), front_inserter(deq1));
   cout << "\ndeq1 = ";
   print_elems_from_to(deq1.cbegin(), deq1.cend());

   set<int> set1;
   cout << "\nCopying elements of lst1 into set1...";
   //Note: this is the only inserter that works for associative collections
   copy(lst1.cbegin(), lst1.cend(), inserter(set1, set1.begin()));
   cout << "\nset1 = ";
   print_elems_from_to(set1.cbegin(), set1.cend());
}

void stl_algorithmsDemo5()
{
   cout << "stl_algorithmsDemo5()..." << endl;

   vector<string> v1 {"cc", "ee", "bb", "aa", "ee", "bb", "aa", "cc"};
   cout << "v1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   cout << "\nSorting v1...";
   sort(v1.begin(), v1.end());
   cout << "\nv1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   cout << "\nPrinting out all the unique elems (removing duplicates)...";
   unique_copy(v1.cbegin(), v1.cend(), ostream_iterator<string>(cout, " "));
}

void stl_algorithmsDemo6()
{
   cout << "stl_algorithmsDemo6()..." << endl;

   vector<int> v1 {1,2,3,4,5,6,7,8,9};
   cout << "v1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   cout << "\nPrinting out all elements in reverse order...";
   cout << "\nv1 = [";
   copy(v1.cbegin(), v1.cend(), ostream_iterator<int>(cout, " "));
   cout << "]";
}

void stl_algorithmsDemo7()
{
   cout << "stl_algorithmsDemo7()..." << endl;

   vector<int> v1{1,2,3,1,2,3,1,2,3};
   cout << "v1 = ";
   print_elems_from_to(v1.cbegin(), v1.cend());

   cout << "\nRemoving from v1 all elements with value 3...";
   vector<int>::iterator it1 = remove(v1.begin(), v1.end(), 3); //or auto it =
   cout << "\nv1 = ";
   print_elems_from_to(v1.begin(), it1);

   cout << "\nWithout using the new 'end' marker 'it1'...";
   cout << "\nv1 = ";
   print_elems_from_to(v1.begin(), v1.end());
}


void stl_algorithmsDemo8()
{
   cout << "stl_algorithmsDemo8()..." << endl;

   multiset<int> mset1{1,2,3,1,2,3,1,2,3};
   cout << "mset1 = ";
   print_elems_from_to(mset1.cbegin(), mset1.cend());

   cout << "\nRemoving from mset1 all elements with value 2...";
   //Note that: algorithm remove() does not work
   mset1.erase(2);
   cout << "\nset1 = ";
   print_elems_from_to(mset1.cbegin(), mset1.cend());
}

template <typename T> void print_elem(T elem)
{
   cout << elem << ' ';
}

int sqr(int val)
{
   return val * val;
}

void stl_algorithmsDemo9()
{
   cout << "stl_algorithmsDemo9()..." << endl;

   vector<int> v1{1,2,3,4,5,6,7,8,9};

   cout << "Printing elements of v1 with the use of 'for_each'...";
   cout << "\nmset1 = [";
   for_each(v1.cbegin(), v1.cend(), print_elem<int>);
   cout << "]";

   deque<int> deq1;
   cout << "\nMapping function 'sqr' over v1, and saving the result to deq1...";
   transform(v1.cbegin(),v1.cend(), std::back_inserter(deq1), sqr);
   cout << "\ndeq1 = ";
   print_elems_from_to(deq1.cbegin(), deq1.cend());

}

template <typename T> bool binarySearch(vector<T> v1, T value)
{
  cout << "binarySearch()..." << endl;
  sort(v1.begin(), v1.end()) ; 
 
  int deb = 0 ;
  int end = v1.size() ; 

  while (deb <= end) { 
        int m = deb + (end - deb) / 2; 

        // Check if value is present at mid 
        if (v1[m] == value) { 
		return true; }
            
        // If value greater, ignore left half 
        if (v1[m] < value){ 
            deb = m + 1; 
        }
        // If value is smaller, ignore right half 
        else{
            end = m - 1; 
	}
    } 
    // if we reach here, then element was not present
    return false;
}




int main()
{

   vector<int> v2 ={5,6,2,3,95,66,6,3,12,32,11,9} ;
   cout << "filter ()..." << endl;
   cout << v2 << endl;
   vector<int> v4 = filter(v2, 6) ; 
   cout << v2 << endl;



   vector<int> v1 ={5,6,2,3,95,66,6,3,12,32,11,9,986} ;

// find algorithm 
   cout << "find algorithm ()..." << endl;
   clock_t begin1 = clock() ;
   vector<int>::iterator it;

   it = find (v1.begin(), v1.end(), 12);
   if (it != v1.end())
    cout << "Element found in v1: " << *it << '\n';
   else{
    cout << "Element not found in v1\n";
   } 

   clock_t end1 = clock();
   double time_spent1 = (double)(end1 - begin1) / CLOCKS_PER_SEC;
   cout << "Time spent : " << time_spent1 << endl ; 

// binary search 
   clock_t begin2 = clock() ;
   bool resBS = binarySearch(v1,12 );
   if (resBS){
    cout << "Element found in v1 \n";
   }
   else{
    cout << "Element not found in v1\n";
   } 


   clock_t end2 = clock();
   double time_spent2 = (double)(end2 - begin2) / CLOCKS_PER_SEC;
   cout << "Time spent : " << time_spent2 << endl ; 


   //stl_algorithmsDemo1(); cout << "\n\n";
   //stl_algorithmsDemo2(); cout << "\n\n";
   //stl_algorithmsDemo3(); cout << "\n\n";
   //stl_algorithmsDemo4(); cout << "\n\n";
   //stl_algorithmsDemo5(); cout << "\n\n";
   //stl_algorithmsDemo6(); cout << "\n\n";
   //stl_algorithmsDemo7(); cout << "\n\n";
   //stl_algorithmsDemo8(); cout << "\n\n";
   //stl_algorithmsDemo9(); cout << "\n\n";

   return 0;
}


