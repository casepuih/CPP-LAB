#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>

using namespace std;


template <typename T>
class LinearFunction;

template <typename T>
ostream& operator<<(ostream&, const LinearFunction<T>&);


// f(x) = a * x + b
template <typename T> class LinearFunction
{
public:
   LinearFunction(const char* name, T a, T b = 0) : name_{name}, a_{a}, b_{b} {}
   T operator()(T x) { return a_ * x + b_; }

private:
   const char* name_;
   T a_;
   T b_;

   friend ostream& operator<< <>(ostream&, const LinearFunction<T>&);
};

template <typename T> ostream& operator<<(ostream& out, const LinearFunction<T>& f)
{
   T b = (f.b_ < 0) ? (-f.b_) : (f.b_);
   if (f.b_ < 0) {
      out << f.name_ << "(x) = " << f.a_ << " * x - " << b;
   } else if (fabs(f.b_) < 1e-15) {
      out << f.name_ << "(x) = " << f.a_ << " * x";
   } else { // f.b_ > 0
      out << f.name_ << "(x) = " << f.a_ << " * x + " << b;
   }

   return out;
}


void funcObjectDemo1()
{
   cout << "funcObjectDemo1()...\n";
   LinearFunction<int> f1("f1", 2, 1);// f1(x) = 2 * x + 1
   cout << f1 << endl;
   for (int i = 0; i < 5; ++i) {
      cout << "f1(" << i << ") = " << f1(i) << endl;
   }

   LinearFunction<double> f2("f2", M_PI, M_E);// f1(x) = pi * x + e
   cout << "\n" << f2 << endl;
   for (double d = 0; d < 5; d += 1) {
      cout << "f2(" << d << ") = " << f2(d) << endl;
   }
}

template<typename T> class Less_than {
   const T val;
public:
   Less_than(const T& v) :val(v) { }
   // {'function call' | 'call' | 'application'} operator
   bool operator()(const T& x) const { return x<val; } // call operator
};


template<typename Cont, typename P> int count(const Cont& c, P pred)
{
   int cnt = 0;
   for (const auto& x : c) {
      if (pred(x)) ++cnt;
   }
   return cnt;
}


template<typename Cont, typename Oper> void for_all(const Cont& xs, Oper op)
{
   for (auto x : xs) {
      op(x);
   }
}


template <typename T> void print_it(T elem)
{
   cout << elem << ' ';
}


inline bool isOdd(int num)
{
   return num % 2 != 0;
}


void funcObjectDemo2()
{
   cout << "funcObjectDemo2()...\n";
   vector<int> v1{1,2,3,4,5,6,7,8,9};
   cout << "v1 = [ ";
   for_all(v1, print_it<int>);
   cout << "]";

   cout << "\nNumber of values in v1 that are smaller than " << 6 << " = "
       << count(v1, Less_than<int>{6});

   cout << "\nRemoving all odd values...";
   auto it = remove_if(v1.begin(), v1.end(), isOdd);
   cout << "\nv1 = [ ";
   for_each(v1.begin(), it, print_it<int>);
   cout << "]";
}


void funcObjectDemo3()
{
   cout << "funcObjectDemo3()...\n";
   vector<int> v1{5,6,9,4,7,2,1,8,3};
   cout << "v1 = [ ";
   for_all(v1, print_it<int>);
   cout << "]";

   cout << "\nSorting v1 in increasing order...";
   sort(v1.begin(), v1.end(), std::less<int>());
   cout << "\nv1 = [ ";
   for_all(v1, print_it<int>);
   cout << "]";

   cout << "\nSorting v1 in decreasing order...";
   sort(v1.begin(), v1.end(), std::greater<int>());
   cout << "\nv1 = [ ";
   for_all(v1, print_it<int>);
   cout << "]";
}

// f(x) = a * x² + b *x + c
template <typename T> class QuadraticFunction;

template <typename T> ostream& operator<<(ostream&, const QuadraticFunction<T>&);

template <typename T> class QuadraticFunction {

public:
   QuadraticFunction(const char* name, T a, T b = 0, T c=0) : name_{name}, a_{a}, b_{b}, c_{c} {}
   T operator()(T x) { return a_ * pow(x,2) + b_ * x + c_; }

private:
   const char* name_;
   T a_;
   T b_;
   T c_;

   friend ostream& operator<< <>(ostream&, const QuadraticFunction<T>&);
};

template <typename T> ostream& operator<<(ostream& out, const QuadraticFunction<T>& f)
{

   T b = (f.b_ < 0) ? (-f.b_) : (f.b_);
   T c = (f.c_ < 0) ? (-f.c_) : (f.c_) ;



   if (f.b_ < 0) {
      out << f.name_ << "(x) = " << f.a_ << " * x² - " << b << " * x";
   } else if (fabs(f.b_) < 1e-15) {
      out << f.name_ << "(x) = " << f.a_ << " * x²";
   } else { // f.b_ > 0
      out << f.name_ << "(x) = " << f.a_ << " * x² + " << b << " * x";
   }

   if (f.c_ < 0) {
     out << " - " << c;
   } else if (fabs(f.c_) < 1e-15) {
      out <<" " ;
   } else { // f.c_ > 0
     out << "  + " << c;
   }

   return out;
}


template <typename T> ostream& operator<<(ostream &out, const vector<T> &v)
{
  out << "[";
  const auto vs = v.size();
  if (vs > 0) {
    for (size_t i = 0; i < vs - 1; ++i) {
      out << v[i] << ",";
    }
    out << v.at(vs - 1); // out << v[vs - 1];
  }
  out << "]";

  return out;
}





template <class T > class MultiplyBy{
private:

   T Factor;// the value to multiply by

public:

   MultValue(const T &_Val) : Factor(_Val) { } // constructor initializes the value to multiply by

   T operator()(T &elem) {
	return (elem * Factor);
   }
};


int main()
{
   //funcObjectDemo1(); cout << "\n";
   //funcObjectDemo2(); cout << "\n\n";
   //funcObjectDemo3(); cout << "\n";
   //QuadraticFunction<int> f1("f1", 2, 2,6);// f1(x) = 2 * x*x + 2*x +6 
   //cout << f1 << endl;


   vector<int> v = {1,2,3,4,5,6,7,8,9};	
   cout << " old :" << v << endl ;
   transform(v.begin(), v.end(), v.begin(), MultValue<int>(10));
   cout << " new :" << v << endl ; 

   return 0;
}
