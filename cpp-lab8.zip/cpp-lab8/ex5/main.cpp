#include <iostream>
#include <iterator>
#include <algorithm>
#include <deque>
#include <array>
#include <list>
#include <forward_list>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <string.h>


using namespace std;

template <typename IterT>
inline bool isThisLastElem(IterT curElemIter, IterT endIter)
{
   return (++curElemIter == endIter);
}


template <typename IterT>
void print_elems_from_to(IterT begin, IterT end)
{
   cout << "[";
   IterT it = begin;
   for (it = begin; it != end; ++it) {
      cout << (*it);
      if (!isThisLastElem(it, end)) {
         cout << ",";
      }
   }
   cout << "]";
}

void deqDemo()
{
   cout << "1) deqDemo()..." << endl;

   deque<int> ints {0};
   for (int i = 1; i < 10;++i) {
      ints.push_back(i);
      ints.push_front(-i);
   }

   cout << "deque ints = ";
   print_elems_from_to(ints.begin(), ints.end());

   cout << "\nPopping 1 elem from the front and the back...";
   ints.pop_front();
   ints.pop_back();
   cout << "\ndeque ints = ";
   print_elems_from_to(ints.begin(), ints.end());

   cout << "\nPrinting elems with the use of ostream_iterator...";
   cout << "\ndeque ints = [";
   copy (ints.cbegin(), ints.cend(),
        ostream_iterator<int>(cout," "));
   cout << "]";

   cout << "\nPrinting elems in reverse order with the use of ostream_iterator...";
   cout << "\ndeque ints = [";
   copy (ints.crbegin(), ints.crend(),
        ostream_iterator<int>(cout," "));
   cout << "]";
}


void cpp11_arrayDemo()
{
   cout << "2) cpp11_arrayDemo()..." << endl;

   array<string,10> cpp11_str_arr = { "one", "two", "three" };
   cout << "cpp11_str_arr = ";
   print_elems_from_to(cpp11_str_arr.begin(), cpp11_str_arr.end());

   array<double,5> cpp11_double_arr1; //no initialization
   cout << "\ncpp11_double_arr1 = ";
   print_elems_from_to(cpp11_double_arr1.begin(), cpp11_double_arr1.end());

   array<double,5> cpp11_double_arr2{}; //C++11 initialization
   cout << "\ncpp11_double_arr2 = ";
   print_elems_from_to(cpp11_double_arr2.begin(), cpp11_double_arr2.end());

   cout << "\nSetting elem value to 'ONE' at index 0...";
   cpp11_str_arr.at(1) = "ONE";
   cout << "\ncpp11_double_arr2.at(1) = ";
   cout << cpp11_str_arr.at(1);

   cout << "\nReading elem at index 100...";
   cout << "\ncpp11_double_arr2.at(20) = ";
   try {
     cout << cpp11_str_arr.at(20);
   } catch (std::out_of_range&) {
     cout << "out_of_range error detected!";
   }
}

void listDemo()
{
   cout << "3) listDemo()..." << endl;
   list<char> letters;

   for (char c = 'A'; c <= 'Z'; ++c) {
      letters.push_back(c);
   }
   cout << "letters = ";
   print_elems_from_to(letters.begin(), letters.end());

   list<char> digits{'0','1','3','4','5','6','7','8','9'};

   cout << "\nInserting * before 'P'";
   auto it = find(letters.begin(), letters.end(), 'P');
   letters.insert(it, '*');
   cout << "\nletters = ";
   print_elems_from_to(letters.begin(), letters.end());

   cout << "\nDeleting 'G'...";
   letters.erase(find(letters.begin(), letters.end(), 'G'));
   cout << "\nletters = ";
   print_elems_from_to(letters.begin(), letters.end());

   cout << "\nSplicing letters and digits (starting from 'E')...";
   letters.splice(find(letters.begin(), letters.end(), 'E'),
               digits, digits.begin(), digits.end());
   cout << "\nletters spliced with digits = ";
   print_elems_from_to(letters.begin(), letters.end());
}

void forward_listDemo()
{
   cout << "4) forward_listDemo()..." << endl;
   forward_list<int> ints_fl;
   for (int i = 0; i < 10; ++i) {
      ints_fl.push_front(i);
   }
   cout << "ints_fl = ";
   print_elems_from_to(ints_fl.begin(), ints_fl.end());

   /*
    * Note: calling ints_fl.resize() is really an "expensive" operation here!
    * It has linear complexity because to reach the end, you have
    * to go element-by-element through the whole list.
    *
    * But this is one of the operations almost all sequence containers provide,
    * ignoring possible bad performance.
    */
   cout << "\nResizing the list to 20 elems, with (-1) as the value for each node...";
   ints_fl.resize(20,-1);
   cout << "\nints_fl = ";
   print_elems_from_to(ints_fl.begin(), ints_fl.end());

}


void setAndMultisetDemo()
{
    cout << "5) setAndMultisetDemo()..." << endl;

    // Note the order of the elements in the initialization list
    set<int> ins_set {4,2,8,7,5,3,6,1};
    cout << "ins_set initilized with {4,2,8,7,5,3,6,1} = ";
    print_elems_from_to(ins_set.begin(), ins_set.end());

    cout << "\nInserting 9 to the set...";
    ins_set.insert(9);
    cout << "\nins_set = ";
    print_elems_from_to(ins_set.begin(), ins_set.end());

    cout << "\nTrying to insert 9 once again...";
    ins_set.insert(9);
    cout << "\nins_set = ";
    print_elems_from_to(ins_set.begin(), ins_set.end());

    cout << "\n\nAnd now the same with multiset...";
    multiset<int> ins_multiset {4,2,8,7,5,3,6,1};
    cout << "\nins_multiset initilized with {4,2,8,7,5,3,6,1} = ";
    print_elems_from_to(ins_multiset.begin(), ins_multiset.end());

    cout << "\nInserting 9 to the multiset...";
    ins_multiset.insert(9);
    cout << "\nins_multiset = ";
    print_elems_from_to(ins_multiset.begin(), ins_multiset.end());

    cout << "\nTrying to insert 9 once again...";
    ins_multiset.insert(9);
    cout << "\nins_multiset = ";
    print_elems_from_to(ins_multiset.begin(), ins_multiset.end());

    cout << "\nInserting ins_set to ins_multiset...";
    ins_multiset.insert(ins_set.begin(), ins_set.end());
    cout << "\nins_multiset = ";
    print_elems_from_to(ins_multiset.begin(), ins_multiset.end());
}


template <typename IterT>
void print_assoc_elems_from_to(IterT begin, IterT end)
{
   cout << "{";
   IterT it = begin;
   for (it = begin; it != end; ++it) {
      cout << "{" << it->first << "," << it->second << "}";
      if (!isThisLastElem(it, end)) {
         cout << ",";
      }
   }
   cout << "}";
}


void mapAndMultiMapDemo()
{
   cout << "6) mapAndMultiMapDemo()..." << endl;
   map<int,string> arabic2RomanMap { {3,"III"}, {2,"II"}, {1,"I"} };

   cout << "arabic2RomanMap initilized with {{3,'III'},{2,'II'},{1,'I'}} = ";
   print_assoc_elems_from_to(arabic2RomanMap.begin(), arabic2RomanMap.end());

   cout << "\nPrinting arabic2RomanMap values only...\n";
   for (auto elem : arabic2RomanMap) {
      cout << elem.second << endl;
   }

   cout << "Adding the mappings for 4 and 5..." << endl;
   arabic2RomanMap.insert({5,"V"});
   arabic2RomanMap.insert({4,"IV"});
   cout << "arabic2RomanMap = ";
   print_assoc_elems_from_to(arabic2RomanMap.begin(), arabic2RomanMap.end());

   cout << "\nTrying to add the mapping for 4 again...";
   arabic2RomanMap.insert({4,"IV"});
   cout << "\narabic2RomanMap = ";
   print_assoc_elems_from_to(arabic2RomanMap.begin(), arabic2RomanMap.end());

   cout << "\n\nAnd now the same with multimap...";
   multimap<int,string> arabic2RomanMMap { {3,"III"}, {2,"II"}, {1,"I"} };

   cout << "\narabic2RomanMMap initilized with {{3,'III'},{2,'II'},{1,'I'}} = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());

   cout << "\nPrinting arabic2RomanMMap <key,value>...\n";
   for (const auto& elem : arabic2RomanMMap) {
      cout << elem.first << ": " << elem.second << endl;
   }

   cout << "\nPrinting arabic2RomanMMap values only...\n";
   for (auto elem : arabic2RomanMMap) {
      cout << elem.second << endl;
   }

   cout << "Adding the mappings for 4 and 5...";
   arabic2RomanMMap.insert({5,"V"});
   arabic2RomanMMap.insert({4,"IV"});
   cout << "\narabic2RomanMap = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());

   cout << "\nTrying to add the mapping for 4 again...";
   arabic2RomanMMap.insert({4,"IV"});
   cout << "\narabic2RomanMMap = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());

   cout << "\nInserting arabic2RomanMap to arabic2RomanMMap...";
   arabic2RomanMMap.insert(arabic2RomanMap.begin(), arabic2RomanMap.end());
   cout << "\narabic2RomanMMap = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());
}
void unorderedSetAndUnorderedMultiSetDemo()
{
   cout << "7) unorderedSetAndUnorderedMultiSetDemo()..." << endl;

   // Note the order of the elements in the initialization list
   unordered_set<int> ins_uset {4,2,8,7,5,3,6,1};
   cout << "ins_uset initilized with {4,2,8,7,5,3,6,1} = ";
   print_elems_from_to(ins_uset.begin(), ins_uset.end());

   cout << "\nInserting 9 to the set...";
   ins_uset.insert(9);
   cout << "\nins_uset = ";
   print_elems_from_to(ins_uset.begin(), ins_uset.end());

   cout << "\nTrying to insert 9 once again...";
   ins_uset.insert(9);
   cout << "\nins_uset = ";
   print_elems_from_to(ins_uset.begin(), ins_uset.end());

   cout << endl;
   cout << "And now the same with unordered_multiset...";

   unordered_multiset<int> ins_umultiset {4,2,8,7,5,3,6,1};
   cout << "\nins_umultiset initilized with {4,2,8,7,5,3,6,1} = ";
   print_elems_from_to(ins_umultiset.begin(), ins_umultiset.end());

   cout << "\nInserting 9 to the unordered multiset...";
   ins_umultiset.insert(9);
   cout << "\nins_umultiset = ";
   print_elems_from_to(ins_umultiset.begin(), ins_umultiset.end());

   cout << "\nTrying to insert 9 once again...";
   ins_umultiset.insert(9);
   cout << "\nins_umultiset = ";
   print_elems_from_to(ins_umultiset.begin(), ins_umultiset.end());

   cout << "\nInserting ins_set to ins_multiset...";
   ins_umultiset.insert(ins_uset.begin(), ins_uset.end());
   cout << "\nins_umultiset = ";
   print_elems_from_to(ins_umultiset.begin(), ins_umultiset.end());
}

void unorderedMapAndUnorderedMultiMapDemo()
{
   cout << "8) unorderedMapAndUnorderedMultiMapDemo()..." << endl;

   unordered_map<int,string> arabic2RomanMap { {3,"III"}, {2,"II"}, {1,"I"} };

   cout << "arabic2RomanMap initilized with {{3,'III'},{2,'II'},{1,'I'}} = ";
   print_assoc_elems_from_to(arabic2RomanMap.begin(), arabic2RomanMap.end());

   cout << "\nPrinting arabic2RomanMap values only...\n";
   for (auto elem : arabic2RomanMap) {
      cout << elem.second << endl;
   }

   cout << "Adding the mappings for 4 and 5...";
   arabic2RomanMap.insert({5,"V"});
   arabic2RomanMap[4] = "IV"; // <- using the syntax of an associative array
   cout << "\narabic2RomanMap = ";
   print_assoc_elems_from_to(arabic2RomanMap.begin(), arabic2RomanMap.end());

   cout << "\nTrying to add the mapping for 4 again...";
   arabic2RomanMap.insert({4,"IV"});
   cout << "\narabic2RomanMap = ";
   print_assoc_elems_from_to(arabic2RomanMap.begin(), arabic2RomanMap.end());

   cout << "And now the same with unordered_multimap...";
   unordered_multimap<int,string> arabic2RomanMMap { {3,"III"}, {2,"II"}, {1,"I"} };

   cout << "\narabic2RomanMMap initilized with {{3,'III'},{2,'II'},{1,'I'}} = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());

   cout << "\nPrinting arabic2RomanMMap values only...\n";
   for (auto elem : arabic2RomanMMap) {
      cout << elem.second << endl;
   }

   cout << "Adding the mappings for 4 and 5...";
   arabic2RomanMMap.insert({5,"V"});
   arabic2RomanMMap.insert({4,"IV"});
   cout << "\narabic2RomanMap = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());

   cout << "\nInserting arabic2RomanMap to arabic2RomanMMap...";
   arabic2RomanMMap.insert(arabic2RomanMap.begin(), arabic2RomanMap.end());
   cout << "\narabic2RomanMMap = ";
   print_assoc_elems_from_to(arabic2RomanMMap.begin(), arabic2RomanMMap.end());
}


template <typename T> void print_deque_summary (const deque<T> &d, const char* name = "")
{
	cout << "\nSummary deque: \n" ;

	int size = (int)d.size() ;

	  const char* d_name = (strlen(name) == 0) ? "d" : name;
	  cout << d_name << ".size() = " << d.size() << endl ;


	if (size>10) {

		cout << "Too much elements ...." << endl ;
		cout << "first element : " <<d[0] << endl;
		cout << "last element : " << d[size-1] ;

	}else {
		int ind = 0 ;
		for (T val : d) {
			cout << "d[" << ind <<"] = " << val << "\n" ;
			ind++ ;
		}
	}
}



int main()
{
   //deqDemo(); cout << "\n\n";
   //cpp11_arrayDemo(); cout << "\n\n";
   //listDemo(); cout << "\n\n";
   //forward_listDemo(); cout << "\n\n";
   //setAndMultisetDemo(); cout << "\n\n";
   //mapAndMultiMapDemo(); cout << "\n\n";
   //unorderedSetAndUnorderedMultiSetDemo(); cout << "\n\n";
   //unorderedMapAndUnorderedMultiMapDemo();
   deque<int> d1 = {6,69,5,3,5,9,6} ; 
   print_deque_summary(d1) ; 
   return 0;
}

