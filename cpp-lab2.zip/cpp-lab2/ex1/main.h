#ifndef MAIN_H
#define MAIN_H


class main
{
public:
    main();
};

#endif // MAIN_H