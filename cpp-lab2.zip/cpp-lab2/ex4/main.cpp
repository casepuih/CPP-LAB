#include <iostream>

using namespace std;

void fun1()
{
  float f1 = 0.1f, f2 = 0.3f, f3 = 0.4f;
  float f4 = (f1 + f2) + f3;
  float f5 = f1 + (f2 + f3);

  if (f4 == f5) {
      cout << "f4 == f5" << endl;
  } else {
      cout << "f4 != f5" << endl;
  }
}

int absInt(int x)
{
  return (x >= 0) ? x : -x;
}

void switchDemo(char c)
{
  switch (c) {
  case 'y':
     cout << "'y' matched" << endl;
     break;
  case 'n':
     cout << "'n' matched" << endl;
     break;
  case 'c':
     cout << "'c' matched" << endl;
     break;
  default:
     cout << "Default case, please select 'y','n' or 'c'" << endl;
  }
}

void switchDemo2(char c)
{
  cout << c <<" is the letter" << endl;
  switch (c) {
  case 'y':
     cout << "'y' matched" << endl;
  case 'n':
     cout << "'n' matched" << endl;
  case 'c':
     cout << "'c' matched" << endl;
  default:
     cout << "Default case, please select 'y','n' or 'c'" << endl;
  }
}



int main()
{
  fun1();
  switchDemo2('c');
  cout << "absInt(-3) = " << absInt(-3) << endl;

  return 0;
}
