#include <iostream>
#include <vector>
#include <chrono>

int sum5(int elems[], size_t size)
{
  if (size == 0) { return 0; }
  else { return sum5(elems, size - 1) + elems[size - 1]; }
}

long factR(int n)
{
  if (n <= 1) { return 1; }
  else { return n * factR(n - 1); }
}

long factRloop(int n)
{
  long res = 1 ; 
  for (int i = 1 ; i <= n ; i++) {
      res = res * i ; 
  } 
  return res ;
}

int maxVector (std::vector<int> v, int size) {

  if (size == 1 ){
	return v[0] ;
  }
   return std::max(v[size-1], maxVector(v, size-1));
}


int fibR(int n)
{
  if (n <= 0) { return 0;}
  else if (n == 1) { return 1; }
  else { return fibR(n - 2) + fibR(n - 1); }
}

int main()
{
  using namespace std;

  int a1[] = {0,1,2,3,4};
  constexpr size_t a1Size = sizeof(a1) / sizeof (a1[0]);

  std::chrono::steady_clock::time_point start1, end1;
  std::chrono::steady_clock::time_point start2, end2;


  start1 = std::chrono::steady_clock::now();
  cout << "factR(20) = " << factR(20) << endl;
  end1 = std::chrono::steady_clock::now();
  cout << " took " << std::chrono::duration_cast<std::chrono::microseconds>(end1 - start1).count()<< " us." << endl;
  
  start2 = std::chrono::steady_clock::now();
  cout << "factRloop(20) = " << factRloop(20) << endl;
  end2 = std::chrono::steady_clock::now();
  cout << " took " << std::chrono::duration_cast<std::chrono::microseconds>(end2 - start2).count()<< " us." << endl;



  cout << "sum5(10) = " << sum5(a1, a1Size) << endl;

  std::chrono::steady_clock::time_point start, end;

  int n4Fib = 45;
  start = std::chrono::steady_clock::now();
  fibR(n4Fib);
  end = std::chrono::steady_clock::now();

  cout << "fibR(" << n4Fib << ") took "
       << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count()
       << "us.\n";

  std::vector<int> v1 = {5,6,8,9,2} ;

  for (int i : v1) {std::cout << i << " " ;}  
  //std::cout << "vector : " << v1 << std::endl ; 
  int res = maxVector(v1,5) ; 
  std::cout << " max value = "<< res << std::endl; 
}
