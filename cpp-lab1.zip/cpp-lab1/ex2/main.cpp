// main.cpp
#include <iostream>
#include "add.h"

int main()
{
  std::cout << "add(1,2) = " << add(1,2) << std::endl;
  std::cout << "SQR(2+3) = " << SQR(2+3);
  return 0;
}
