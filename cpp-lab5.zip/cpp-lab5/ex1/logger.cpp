#include <iostream>
#include <vector>

using std::cout;
using std::endl;

//Note that the singleton (design) pattern is used here
class Logger
{
public:
  static Logger& getInstance()
  {
    static Logger theInstance;
    return theInstance;
  }

  void logMsg(const char* msg);

  void logMsg(const char* fileName, const char* msg);

  void printAll();

  //Logger(const Logger &) = delete;
  //Logger& operator=(const Logger &) = delete;

private:
  std::vector<char> msgs_;
  Logger() {} // private constructor
  Logger(const Logger&);                 // Prevent copy-construction
  Logger& operator=(const Logger&);

};


void Logger::logMsg(const char* msg){

	cout << msg << endl;

}

void Logger::logMsg(const char* fileName, const char* msg){

	cout << " The file : "<< fileName << " : " <<msg << endl;
}
void Logger::printAll(){

	cout << " printAll function ! "<< endl;
}


int main()
{
	Logger &logger = Logger::getInstance();
	logger.logMsg("File does not exist");
	logger.logMsg("Fileblabla", "File does not exist");
	logger.logMsg("Load balancer is not responding");
	logger.printAll();

	return 0;

}
