#include <iostream>

using std::cout;
using std::endl;

class ClassThatCountsItsInstances
{
	static int ctrInstances ;  // counter of instances

public:

	ClassThatCountsItsInstances() ; // constructor
  	~ClassThatCountsItsInstances() ; // destructor

  	static void countInstances() ; // static function member to count instances by using a static data member
} ;

int ClassThatCountsItsInstances::ctrInstances = 0 ; // initialize the static counter

ClassThatCountsItsInstances::ClassThatCountsItsInstances(){

	++ctrInstances ; // at each call of the constructor, the counter incrementes
	cout << "++ construction : there are " << ctrInstances << " instances\n" ;
}

ClassThatCountsItsInstances::~ClassThatCountsItsInstances(){

	--ctrInstances ;  // at each call of the destructor, the counter deincrementes
	cout << "-- construction : there are " << ctrInstances << " instances \n" ;
}


void ClassThatCountsItsInstances::countInstances(){

	cout << " There are  " << ctrInstances << " instances ! \n" ;
}

int main()
{
	ClassThatCountsItsInstances a ;
	ClassThatCountsItsInstances::countInstances() ;
	ClassThatCountsItsInstances b ;
	ClassThatCountsItsInstances::countInstances() ;
	ClassThatCountsItsInstances c ;
	ClassThatCountsItsInstances::countInstances() ;

	return 0;
}
