#include <iostream>

int argByValue(int i)
{
  return 2 * i;
}

int argByReference(int &r)
{
  r *= 2;
  return 5 * r;
}

int argByPointer(int *p)
{
  *p *= 2; // = *p = *p * 2;
  return 5 * *p; // = 5 * (*p)
}

//int* add(int *px, int *py)
//{
//  int sum = *px + *py;
//  return &sum;
//}

int* add(int *px, int *py)
{
  int *sum = new int ;
  *sum= *px + *py;

  return sum;
}


void swap2Ints(int *x, int *y){

    int tmp = *x;
    *x = *y;
    *y = tmp;
}

void swap2(int *px, int *py)
{
  int *tmp = px;	// tmp points to px
  px = py; // px points to py (*px = 2 and px = address of py)
  py = tmp; // py points to temp (*py = 1 and py = address of tmp)
}


int main()
{
  using std::cout;
  using std::endl;

//  int x = 1;
//  cout << "x = " << x << endl;

//  cout << "Calling argByValue(x):" << endl;
//  int y = argByValue(x);
//  cout << "x = " << x << ", y = " << y << endl;

//  cout << "Calling argByReference(x):" << endl;
//  y = argByReference(x);
//  cout << "x = " << x << ", y = " << y << endl;

//  cout << "Calling argByPointer(&x):" << endl;
//  y = argByPointer(&x);
//  cout << "x = " << x << ", y = " << y << endl;


  int a = 2 ;
  int b = 3 ; 
  
//  cout << "Calling add(*px, *py)" << endl;
//  cout << a << " + " << b <<" =" << *(add(&a,&b)) << endl;
  

//  cout << "Before swap2Ints(*x, *y)" << endl;
//  cout << "a = " << a << ", b = " << b << endl; 
//  cout << "Calling swap2Ints(*x, *y)" << endl;
//  swap2Ints(&a, &b) ; 
//  cout << "a = " << a << ", b = " << b << endl; 


  int x = 1, y = 2;
  cout << "x = " << x << ", y = " << y << endl;
  swap2(&x, &y);
  cout << "x = " << x << ", y = " << y << endl;

  return 0;
}
